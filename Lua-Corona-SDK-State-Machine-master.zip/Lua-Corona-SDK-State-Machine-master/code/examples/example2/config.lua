application =
{
        content =
        {
                width = 320,
                height = 480,
                scale = "letterbox",
				xAlign = "left",
				yAlign = "top",
				fps = 60,
				antialias = false,
        },
}