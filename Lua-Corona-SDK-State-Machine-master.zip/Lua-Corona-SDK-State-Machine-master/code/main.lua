

function runUnitTestSuite()
	require "testsmain"
end

function runExample1_basic()

end

function runExample2_heiarchical()

end

function runExample3_classBased()

end

runUnitTestSuite()
--runExample1_basic()